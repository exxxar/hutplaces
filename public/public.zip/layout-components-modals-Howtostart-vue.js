(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["layout-components-modals-Howtostart-vue"],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/modals/Howtostart.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/modals/Howtostart.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'promo',
  data: function data() {
    return {
      settings: {
        maxScrollbarLength: 60
      }
    };
  },
  methods: {}
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/modals/Howtostart.vue?vue&type=template&id=5990e025&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/modals/Howtostart.vue?vue&type=template&id=5990e025& ***!
  \********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "modal-body" }, [
    _vm._m(0),
    _vm._v(" "),
    _c("div", { staticClass: "modal-logo" }, [
      _c("img", {
        directives: [
          {
            name: "lazy",
            rawName: "v-lazy",
            value: "/img/vk-login-icon.png",
            expression: "'/img/vk-login-icon.png'"
          }
        ],
        attrs: { alt: "" }
      })
    ]),
    _vm._v(" "),
    _c("hr"),
    _vm._v(" "),
    _vm._m(1),
    _vm._v(" "),
    _vm._m(2),
    _vm._v(" "),
    _c("div", { staticClass: "modal-logo" }, [
      _c("img", {
        directives: [
          {
            name: "lazy",
            rawName: "v-lazy",
            value: "/img/money-icon-1.png",
            expression: "'/img/money-icon-1.png'"
          }
        ],
        attrs: { alt: "" }
      })
    ]),
    _vm._v(" "),
    _c("hr"),
    _vm._v(" "),
    _vm._m(3),
    _vm._v(" "),
    _vm._m(4),
    _vm._v(" "),
    _c("hr"),
    _vm._v(" "),
    _vm._m(5),
    _vm._v(" "),
    _c("div", { staticClass: "modal-logo" }, [
      _c("img", {
        directives: [
          {
            name: "lazy",
            rawName: "v-lazy",
            value: "/img/security-icon-1.png",
            expression: "'/img/security-icon-1.png'"
          }
        ],
        attrs: { alt: "" }
      })
    ]),
    _vm._v(" "),
    _c("hr"),
    _vm._v(" "),
    _vm._m(6),
    _vm._v(" "),
    _c("div", { staticClass: "modal-logo" }, [
      _c("img", {
        directives: [
          {
            name: "lazy",
            rawName: "v-lazy",
            value: "/img/time-icon-1.png",
            expression: "'/img/time-icon-1.png'"
          }
        ],
        attrs: { alt: "" }
      })
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _vm._v("Для принятия участия в розыгрыше,"),
      _c("br"),
      _vm._v("\n    необходимо авторизоваться через ВК")
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _vm._v("Перед участием в игре незабудьте"),
      _c("br"),
      _vm._v("\n    пополнить свой счет!")
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _vm._v(" В игре собственная валюта - "),
      _c("span", [_vm._v("Pucks")]),
      _vm._v(".")
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _vm._v("На балансе должно быть досаточное "),
      _c("br"),
      _vm._v("\n    количество средств.")
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("h2", [
      _vm._v("1 "),
      _c("span", [_vm._v("Pucks")]),
      _vm._v(" = 1 Руб")
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _vm._v("Честность выбора победителя можно "),
      _c("br"),
      _vm._v("\n    проверить на сайте "),
      _c("span", [_vm._v("random.org")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _vm._v("Быстрая доставка выигрыша"),
      _c("br"),
      _vm._v("\n    в течении 24-х часов")
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/modals/Howtostart.vue":
/*!*******************************************************!*\
  !*** ./resources/js/components/modals/Howtostart.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Howtostart_vue_vue_type_template_id_5990e025___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Howtostart.vue?vue&type=template&id=5990e025& */ "./resources/js/components/modals/Howtostart.vue?vue&type=template&id=5990e025&");
/* harmony import */ var _Howtostart_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Howtostart.vue?vue&type=script&lang=js& */ "./resources/js/components/modals/Howtostart.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Howtostart_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Howtostart_vue_vue_type_template_id_5990e025___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Howtostart_vue_vue_type_template_id_5990e025___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/modals/Howtostart.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/modals/Howtostart.vue?vue&type=script&lang=js&":
/*!********************************************************************************!*\
  !*** ./resources/js/components/modals/Howtostart.vue?vue&type=script&lang=js& ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Howtostart_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Howtostart.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/modals/Howtostart.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Howtostart_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/modals/Howtostart.vue?vue&type=template&id=5990e025&":
/*!**************************************************************************************!*\
  !*** ./resources/js/components/modals/Howtostart.vue?vue&type=template&id=5990e025& ***!
  \**************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Howtostart_vue_vue_type_template_id_5990e025___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Howtostart.vue?vue&type=template&id=5990e025& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/modals/Howtostart.vue?vue&type=template&id=5990e025&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Howtostart_vue_vue_type_template_id_5990e025___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Howtostart_vue_vue_type_template_id_5990e025___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);